G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.2*
G04 #@! TF.CreationDate,2025-06-18T23:07:30+02:00*
G04 #@! TF.ProjectId,link-eurorack,6c696e6b-2d65-4757-926f-7261636b2e6b,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.2) date 2025-06-18 23:07:30*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.700000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,H7*
X36550000Y-83200000D03*
G04 #@! TD*
G04 #@! TO.C,H6*
X74350000Y-28700000D03*
G04 #@! TD*
G04 #@! TO.C,H8*
X74300000Y-83150000D03*
G04 #@! TD*
G04 #@! TO.C,H5*
X36500000Y-28750000D03*
G04 #@! TD*
M02*
